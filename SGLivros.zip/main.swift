class Livro{
  var titulo: String
  var autor: Autor
  var anoPublicacao: Int
  var disponivel: Bool

  init(titulo: String, autor: Autor, anoPublicacao: Int) {
      self.titulo = titulo
      self.autor = autor
      self.anoPublicacao = anoPublicacao
      self.disponivel = true
      }
    
  func emprestar(){
        self.disponivel = false
  }
    
  func devolver(){
        self.disponivel = true
  }
}

class Autor{
  var nome: String
  var nacionalidade: String
  var anoNascimento: Int

  init(nome: String, nacionalidade: String, anoNascimento: Int){
      self.nome = nome
      self.nacionalidade = nacionalidade
      self.anoNascimento = anoNascimento
  }
}

class Usuario{
  var nome: String
  var email: String
  var livrosEmprestados: [Livro] = []

  init(nome: String, email: String) {
      self.nome = nome
      self.email = email
  }

  func pegarEmprestado(livro: Livro){
    if livro.disponivel {
         livrosEmprestados.append(livro)
           livro.emprestar()
      }else{
        print("Livro indisponível")
      }
  }

  func devolverLivro(livro: Livro) {
    if let index = livrosEmprestados.firstIndex(where: { $0.titulo == livro.titulo }) {
        livrosEmprestados.remove(at: index)
        livro.devolver()  
    }
}

  
}
// Criando instâncias de autores
let autor1 = Autor(nome: "Gege Akutami", nacionalidade: "Britânico", anoNascimento: 1903)
let autor2 = Autor(nome: "Daisuke Hagiwara", nacionalidade: "Japonesa", anoNascimento: 1965)

// Criando instâncias de livros
let livro1 = Livro(titulo: "Jujutusu kaisen 0", autor: autor1, anoPublicacao: 2018)
let livro2 = Livro(titulo: "Horimiya", autor: autor2, anoPublicacao: 2011)
let livro3 = Livro(titulo: "Shibuya Incident", autor: autor1, anoPublicacao: 1945)

// Criando instâncias de usuários
let usuario1 = Usuario(nome: "Biebis", email: "vapoxav423@degcos.com")
let usuario2 = Usuario(nome: "Lock", email: "kdasikdjda@degcos.com")

// Testando operações de empréstimo
print("== Testando operações de empréstimo ==")
usuario1.pegarEmprestado(livro: livro1)  // João pega 1984 emprestado
usuario2.pegarEmprestado(livro: livro2)  // Maria pega Harry Potter emprestado

// Verificando se os livros foram emprestados corretamente
print("\nDisponibilidade dos livros após empréstimos:")
print("\(livro1.titulo): \(livro1.disponivel ? "Disponível" : "Indisponível")")  // Deve mostrar Indisponível
print("\(livro2.titulo): \(livro2.disponivel ? "Disponível" : "Indisponível")")  // Deve mostrar Indisponível

// Testando devolução
print("\n== Testando operações de devolução ==")
usuario1.devolverLivro(livro: livro1)  // João devolve 1984

// Verificando se o livro foi devolvido corretamente
print("\nDisponibilidade dos livros após devoluções:")
print("\(livro1.titulo): \(livro1.disponivel ? "Disponível" : "Indisponível")")  // Deve mostrar Disponível

// Testando quando um livro não está disponível
print("\n== Testando quando um livro já está emprestado ==")
usuario2.pegarEmprestado(livro: livro1)  // Maria tenta pegar 1984, que agora está disponível
usuario1.pegarEmprestado(livro: livro1)  // João tenta pegar 1984 novamente, mas agora Maria já pegou
