struct Produto {
  var nome: String
  var quantidade: Int
  var preco: Double
}

class GerenciadorDeInventario {
  var produtos: [Produto] = []

  func adicionarProduto(produto: Produto) {
      produtos.append(produto)
  }

  func calcularValorTotal() -> Double {
      var total: Double = 0
      for produto in produtos {
          total += produto.preco * Double(produto.quantidade)
      }
      return total
  }

  func listarProdutosAbaixoDe(quantidade: Int) -> [Produto] {
      return produtos.filter { $0.quantidade < quantidade }
  }

  func exibirInformacoesProduto(produto: Produto) {
      print("Nome: \(produto.nome), Quantidade: \(produto.quantidade), Preço: \(produto.preco)")
  }
}

// Testando o código

let produto1 = Produto(nome: "iPhone", quantidade: 5, preco: 5000.0)
let produto2 = Produto(nome: "MacBook", quantidade: 3, preco: 10000.0)
let produto3 = Produto(nome: "Apple Watch", quantidade: 2, preco: 3000.0)

let gerenciador = GerenciadorDeInventario()
gerenciador.adicionarProduto(produto: produto1)
gerenciador.adicionarProduto(produto: produto2)
gerenciador.adicionarProduto(produto: produto3)

// Calculando valor total
let valorTotal = gerenciador.calcularValorTotal()
print("Valor total do inventário: \(valorTotal)")

// Listando produtos abaixo de uma certa quantidade
let produtosAbaixo = gerenciador.listarProdutosAbaixoDe(quantidade: 3)
print("\nProdutos abaixo de quantidade 3:")
for produto in produtosAbaixo {
  gerenciador.exibirInformacoesProduto(produto: produto)
}
